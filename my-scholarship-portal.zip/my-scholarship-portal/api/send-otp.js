import { Resend } from 'resend';
const resend = new Resend(process.env.RESEND_API_KEY);

// Temporary in-memory store for OTPs (or use a Supabase table for production persistence)
global.otpStore = global.otpStore || {};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email is required' });
  }

  // Generate 6-digit OTP
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  global.otpStore[email] = {
    otp,
    expires: Date.now() + 10 * 60 * 1000 // Valid for 10 minutes
  };

  try {
    await resend.emails.send({
      from: 'Norwegian Scholarship Portal <onboarding@resend.dev>',
      to: email,
      subject: 'Verification Code - Norwegian International Scholarship',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px;">
          <h2 style="color: #1e293b; text-align: center;">Norwegian International Scholarship</h2>
          <p style="color: #475569; font-size: 16px;">Hello,</p>
          <p style="color: #475569; font-size: 16px;">Thank you for starting your application for the MSc in Languages and Linguistics. Please use the following 6-digit verification code to proceed:</p>
          <div style="background-color: #f1f5f9; padding: 15px; text-align: center; font-size: 32px; font-weight: bold; letter-spacing: 6px; color: #0f172a; border-radius: 6px; margin: 20px 0;">
            ${otp}
          </div>
          <p style="color: #64748b; font-size: 14px; text-align: center;">This code will expire in 10 minutes. If you did not request this, please ignore this email.</p>
        </div>
      `
    });

    return res.status(200).json({ success: true, message: 'OTP sent successfully' });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}