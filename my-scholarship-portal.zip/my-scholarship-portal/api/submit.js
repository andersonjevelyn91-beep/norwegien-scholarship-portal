import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// Access global store from send-otp.js
global.otpStore = global.otpStore || {};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { action, email, otp, formData } = req.body;

  // ACTION 1: Verify OTP entered by user
  if (action === 'verify-otp') {
    const record = global.otpStore[email];
    if (!record) {
      return res.status(400).json({ success: false, error: 'No OTP found for this email. Please request a new code.' });
    }
    if (Date.now() > record.expires) {
      delete global.otpStore[email];
      return res.status(400).json({ success: false, error: 'OTP has expired. Please request a new code.' });
    }
    if (record.otp !== otp) {
      return res.status(400).json({ success: false, error: 'Invalid verification code.' });
    }

    // Clear OTP after successful check
    delete global.otpStore[email];
    return res.status(200).json({ success: true, message: 'OTP verified successfully' });
  }

  // ACTION 2: Save final application to Supabase database
  if (action === 'submit-application') {
    if (!formData || !formData.email) {
      return res.status(400).json({ success: false, error: 'Invalid application data.' });
    }

    const { data, error } = await supabase
      .from('applications')
      .insert([formData]);

    if (error) {
      return res.status(500).json({ success: false, error: error.message });
    }

    return res.status(200).json({ success: true, data });
  }

  return res.status(400).json({ error: 'Invalid action specified' });
}